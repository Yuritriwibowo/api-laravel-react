import { useEffect, useState } from "react";
import { getProducts, addToCart } from "../api";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // CEK LOGIN
  const isLoggedIn = !!localStorage.getItem("userToken");

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const data = await getProducts();
      setProducts(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Gagal load produk:", err);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async (productId) => {
    if (!isLoggedIn) {
      alert("Silakan login terlebih dahulu untuk menambah ke keranjang");
      return;
    }

    try {
      await addToCart(productId, 1);
      alert("Produk berhasil ditambahkan ke keranjang");
    } catch (err) {
      console.error("Gagal tambah ke keranjang:", err);
      alert("Gagal menambahkan ke keranjang");
    }
  };

  if (loading) {
    return <div className="container py-5">Loading...</div>;
  }

  return (
    <div className="container py-5">
      <h2 className="fw-bold mb-4">Daftar Produk</h2>

      {products.length === 0 ? (
        <p className="text-muted">Produk belum tersedia</p>
      ) : (
        <div className="row g-4">
          {products.map((p) => (
            <div
              className="col-12 col-sm-6 col-md-4 col-lg-3"
              key={p.id}
            >
              <div className="card shadow-sm h-100">
                <img
                  src={`https://tokosiregar.online/uploads/${p.gambar}`}
                  alt={p.judul}
                  className="card-img-top"
                  style={{ height: "220px", objectFit: "cover" }}
                  onError={(e) =>
                    (e.target.src =
                      "https://via.placeholder.com/300x220?text=No+Image")
                  }
                />

                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{p.judul}</h5>

                  <p className="text-muted">
                    Rp {Number(p.harga).toLocaleString("id-ID")}
                  </p>

                  <button
                    className="btn btn-primary mt-auto"
                    onClick={() => handleAddToCart(p.id)}
                  >
                    Tambah ke Keranjang
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
