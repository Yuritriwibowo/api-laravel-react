import axios from "axios";

/* ============================
   BASE API URL (HOSTING)
=============================== */
const API_URL = import.meta.env.VITE_API_URL;

/* ============================
   AUTH HEADER
=============================== */
const userAuthHeader = () => ({
  headers: {
    Authorization: `Bearer ${localStorage.getItem("userToken")}`,
  },
});

const adminAuthHeader = () => ({
  headers: {
    Authorization: `Bearer ${localStorage.getItem("adminToken")}`,
  },
});

/* ============================
   AUTH
=============================== */
export async function adminLogin(email, password) {
  const res = await axios.post(`${API_URL}/admin/login`, { email, password });
  localStorage.setItem("adminToken", res.data.token);
  return res.data;
}

export async function userLogin(email, password) {
  const res = await axios.post(`${API_URL}/login`, { email, password });
  localStorage.setItem("userToken", res.data.token);
  return res.data;
}

export async function userRegister(name, email, password) {
  const res = await axios.post(`${API_URL}/register`, {
    name,
    email,
    password,
  });
  localStorage.setItem("userToken", res.data.token);
  return res.data;
}

/* ============================
   PRODUCT
=============================== */
export async function getProducts() {
  const res = await axios.get(`${API_URL}/products`);

  // ⬇️ PASTI ARRAY
  return Array.isArray(res.data)
    ? res.data
    : Array.isArray(res.data?.data)
    ? res.data.data
    : [];
}

export async function getProductById(id) {
  const res = await axios.get(`${API_URL}/products/${id}`);
  return res.data;
}

export async function createProduct(formData) {
  const res = await axios.post(
    `${API_URL}/products`,
    formData,
    {
      ...adminAuthHeader(),
      headers: {
        ...adminAuthHeader().headers,
        "Content-Type": "multipart/form-data",
      },
    }
  );
  return res.data;
}

export async function updateProduct(id, formData) {
  formData.append("_method", "PUT");

  const res = await axios.post(
    `${API_URL}/products/${id}`,
    formData,
    {
      ...adminAuthHeader(),
      headers: {
        ...adminAuthHeader().headers,
        "Content-Type": "multipart/form-data",
      },
    }
  );
  return res.data;
}

export async function deleteProduct(id) {
  const res = await axios.delete(
    `${API_URL}/products/${id}`,
    adminAuthHeader()
  );
  return res.data;
}

/* ============================
   CART
=============================== */
export async function addToCart(productId, qty = 1) {
  const token = localStorage.getItem("userToken");

  if (!token) {
    throw new Error("User belum login");
  }

  const res = await axios.post(
    `${API_URL}/cart`,
    { product_id: productId, qty },
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  return res.data;
}


export async function getCart() {
  const res = await axios.get(`${API_URL}/cart`, userAuthHeader());
  return res.data;
}

export async function updateCartQty(id, qty) {
  const res = await axios.put(
    `${API_URL}/cart/${id}`,
    { qty },
    userAuthHeader()
  );
  return res.data;
}

export async function deleteCartItem(id) {
  const res = await axios.delete(
    `${API_URL}/cart/${id}`,
    userAuthHeader()
  );
  return res.data;
}

/* ============================
   ORDER
=============================== */
export async function createOrder() {
  const res = await axios.post(
    `${API_URL}/orders`,
    {},
    userAuthHeader()
  );
  return res.data;
}

/* ============================
   ADMIN ORDER
=============================== */
export async function getAdminOrders() {
  const res = await axios.get(
    `${API_URL}/admin/orders`,
    adminAuthHeader()
  );
  return res.data;
}

export async function confirmDp(orderId) {
  const res = await axios.put(
    `${API_URL}/admin/orders/${orderId}/confirm-dp`,
    {},
    adminAuthHeader()
  );
  return res.data;
}

export async function deleteOrder(id) {
  const res = await axios.delete(
    `${API_URL}/admin/orders/${id}`,
    adminAuthHeader()
  );
  return res.data;
}
